import { Injectable, NotFoundException } from '@nestjs/common';
import { Task, CreateTaskDto, UpdateTaskDto } from './task.interface';
import { v4 as uuid } from 'uuid';

@Injectable()
export class TasksService {
  private tasks: Task[] = [
    {
      id: '1',
      title: 'Sample Task',
      description: 'This is a sample task to get you started',
      completed: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  findAll(): Task[] {
    return this.tasks.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  findOne(id: string): Task {
    const task = this.tasks.find(task => task.id === id);
    if (!task) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    return task;
  }

  create(createTaskDto: CreateTaskDto): Task {
    const newTask: Task = {
      id: uuid(),
      ...createTaskDto,
      completed: false,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    this.tasks.push(newTask);
    return newTask;
  }

  update(id: string, updateTaskDto: UpdateTaskDto): Task {
    const taskIndex = this.tasks.findIndex(task => task.id === id);
    if (taskIndex === -1) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }

    const updatedTask = {
      ...this.tasks[taskIndex],
      ...updateTaskDto,
      updatedAt: new Date(),
    };
    
    this.tasks[taskIndex] = updatedTask;
    return updatedTask;
  }

  remove(id: string): void {
    const taskIndex = this.tasks.findIndex(task => task.id === id);
    if (taskIndex === -1) {
      throw new NotFoundException(`Task with ID ${id} not found`);
    }
    this.tasks.splice(taskIndex, 1);
  }
}