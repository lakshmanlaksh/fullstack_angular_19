import { Injectable } from '@nestjs/common';
import { v4 as uuid } from 'uuid';
import { Task } from './task.interface';

@Injectable()
export class TasksService {
  private tasks: Task[] = [];

  findAll(): Task[] {
    return this.tasks;
  }

  findOne(id: string): Task | undefined {
    return this.tasks.find(task => task.id === id);
  }

  create(taskData: Omit<Task, 'id' | 'createdAt'>): Task {
    const now = new Date();
    const newTask: Task = {
      id: uuid(),
      ...taskData,
      createdAt: now,
      updatedAt: now,
    };
    this.tasks.push(newTask);
    return newTask;
  }

  update(id: string, taskData: Partial<Omit<Task, 'id' | 'createdAt' | 'updatedAt'>>): Task | null {
    const taskIndex = this.tasks.findIndex(task => task.id === id);
    if (taskIndex === -1) {
      return null;
    }
    
    this.tasks[taskIndex] = { 
      ...this.tasks[taskIndex], 
      ...taskData,
      updatedAt: new Date()
    };
    return this.tasks[taskIndex];
  }

  delete(id: string): boolean {
    const taskIndex = this.tasks.findIndex(task => task.id === id);
    if (taskIndex === -1) {
      return false;
    }
    
    this.tasks.splice(taskIndex, 1);
    return true;
  }
}