import { Controller, Get, Post, Put, Delete, Body, Param, HttpException, HttpStatus } from '@nestjs/common';
import { TasksService } from './tasks.service';
import { Task } from './task.interface';

@Controller('tasks')
export class TasksController {
  constructor(private readonly tasksService: TasksService) {}

  @Get()
  findAll(): Task[] {
    return this.tasksService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string): Task {
    const task = this.tasksService.findOne(id);
    if (!task) {
      throw new HttpException('Task not found', HttpStatus.NOT_FOUND);
    }
    return task;
  }

  @Post()
  create(@Body() taskData: Omit<Task, 'id' | 'createdAt'>): Task {
    if (!taskData.title || !taskData.description) {
      throw new HttpException('Title and description are required', HttpStatus.BAD_REQUEST);
    }
    return this.tasksService.create(taskData);
  }

  @Put(':id')
  update(@Param('id') id: string, @Body() taskData: Partial<Omit<Task, 'id' | 'createdAt'>>): Task {
    const updatedTask = this.tasksService.update(id, taskData);
    if (!updatedTask) {
      throw new HttpException('Task not found', HttpStatus.NOT_FOUND);
    }
    return updatedTask;
  }

  @Delete(':id')
  delete(@Param('id') id: string): { message: string } {
    const deleted = this.tasksService.delete(id);
    if (!deleted) {
      throw new HttpException('Task not found', HttpStatus.NOT_FOUND);
    }
    return { message: 'Task deleted successfully' };
  }
}