import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskService } from '../../services/task.service';
import { Task } from '../../models/task.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="task-list-container">
      <h2 class="list-title">Your Tasks</h2>
      
      <div class="tasks-grid" *ngIf="tasks$ | async as tasks; else loading">
        <div *ngIf="tasks.length === 0" class="empty-state">
          <div class="empty-icon">📝</div>
          <h3>No tasks yet</h3>
          <p>Create your first task to get started!</p>
        </div>

        <div
          *ngFor="let task of tasks; trackBy: trackByTaskId"
          class="task-card"
          [class.completed]="task.completed"
        >
          <div class="task-header">
            <h3 class="task-title">{{ task.title }}</h3>
            <div class="task-actions">
              <button
                class="action-btn toggle-btn"
                [class.completed]="task.completed"
                (click)="toggleTask(task)"
                [title]="task.completed ? 'Mark as incomplete' : 'Mark as complete'"
              >
                {{ task.completed ? '✓' : '○' }}
              </button>
              <button
                class="action-btn delete-btn"
                (click)="deleteTask(task.id)"
                title="Delete task"
              >
                🗑️
              </button>
            </div>
          </div>

          <p class="task-description">{{ task.description }}</p>

          <div class="task-meta">
            <span class="task-status" [class.completed]="task.completed">
              {{ task.completed ? 'Completed' : 'Pending' }}
            </span>
            <span class="task-date">
              Created: {{ formatDate(task.createdAt) }}
            </span>
          </div>
        </div>
      </div>

      <ng-template #loading>
        <div class="loading-state">
          <div class="loading-spinner"></div>
          <p>Loading tasks...</p>
        </div>
      </ng-template>
    </div>
  `,
  styles: [`
    .task-list-container {
      width: 100%;
    }

    .list-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: #1f2937;
      margin-bottom: 1.5rem;
      text-align: center;
    }

    .tasks-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 1.5rem;
    }

    .task-card {
      background: white;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      border-left: 4px solid #2563eb;
    }

    .task-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }

    .task-card.completed {
      border-left-color: #16a34a;
      background: #f0fdf4;
    }

    .task-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
      margin-bottom: 1rem;
    }

    .task-title {
      font-size: 1.125rem;
      font-weight: 600;
      color: #1f2937;
      margin: 0;
      line-height: 1.4;
      flex: 1;
    }

    .task-card.completed .task-title {
      text-decoration: line-through;
      color: #6b7280;
    }

    .task-actions {
      display: flex;
      gap: 0.5rem;
      flex-shrink: 0;
    }

    .action-btn {
      width: 32px;
      height: 32px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.875rem;
    }

    .toggle-btn {
      background: #e5e7eb;
      color: #6b7280;
    }

    .toggle-btn.completed {
      background: #16a34a;
      color: white;
    }

    .toggle-btn:hover {
      transform: scale(1.1);
    }

    .delete-btn {
      background: #fee2e2;
      color: #dc2626;
    }

    .delete-btn:hover {
      background: #dc2626;
      color: white;
      transform: scale(1.1);
    }

    .task-description {
      color: #4b5563;
      line-height: 1.6;
      margin: 0 0 1rem 0;
      font-size: 0.875rem;
    }

    .task-card.completed .task-description {
      color: #9ca3af;
    }

    .task-meta {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      font-size: 0.75rem;
      color: #6b7280;
      border-top: 1px solid #e5e7eb;
      padding-top: 1rem;
    }

    .task-status {
      padding: 0.25rem 0.75rem;
      border-radius: 20px;
      font-weight: 500;
      background: #fef3c7;
      color: #d97706;
    }

    .task-status.completed {
      background: #dcfce7;
      color: #16a34a;
    }

    .task-date {
      font-size: 0.75rem;
    }

    .empty-state {
      grid-column: 1 / -1;
      text-align: center;
      padding: 3rem 1rem;
      color: #6b7280;
    }

    .empty-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .empty-state h3 {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: 0.5rem;
      color: #374151;
    }

    .loading-state {
      grid-column: 1 / -1;
      text-align: center;
      padding: 3rem 1rem;
      color: #6b7280;
    }

    .loading-spinner {
      width: 40px;
      height: 40px;
      border: 4px solid #e5e7eb;
      border-top: 4px solid #2563eb;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 1rem;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    @media (max-width: 768px) {
      .tasks-grid {
        grid-template-columns: 1fr;
      }

      .task-card {
        padding: 1rem;
      }

      .task-header {
        gap: 0.75rem;
      }

      .task-meta {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
      }
    }
  `]
})
export class TaskListComponent implements OnInit {
  tasks$: Observable<Task[]>;

  constructor(private taskService: TaskService) {
    this.tasks$ = this.taskService.tasks$;
  }

  ngOnInit(): void {
    this.taskService.loadTasks();
  }

  trackByTaskId(index: number, task: Task): string {
    return task.id;
  }

  toggleTask(task: Task): void {
    this.taskService.toggleTaskCompletion(task).subscribe({
      error: (error) => {
        console.error('Error toggling task:', error);
      }
    });
  }

  deleteTask(taskId: string): void {
    if (confirm('Are you sure you want to delete this task?')) {
      this.taskService.deleteTask(taskId).subscribe({
        error: (error) => {
          console.error('Error deleting task:', error);
        }
      });
    }
  }

  formatDate(dateString: Date): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }
}