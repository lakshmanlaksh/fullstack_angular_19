import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { provideHttpClient } from '@angular/common/http';
import { TaskFormComponent } from './components/task-form/task-form.component';
import { TaskListComponent } from './components/task-list/task-list.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, TaskFormComponent, TaskListComponent],
  template: `
    <div class="app-container">
      <header class="app-header">
        <div class="header-content">
          <h1 class="app-title">
            <span class="title-icon">✅</span>
            Task Manager
          </h1>
          <p class="app-subtitle">Organize your tasks efficiently</p>
        </div>
      </header>

      <main class="app-main">
        <div class="content-wrapper">
          <div class="form-section" *ngIf="showForm">
            <app-task-form
              (taskCreated)="onTaskCreated()"
              (cancelled)="onFormCancelled()"
            ></app-task-form>
          </div>

          <div class="action-bar" *ngIf="!showForm">
            <button class="btn btn-primary add-task-btn" (click)="showAddForm()">
              <span class="btn-icon">+</span>
              Add New Task
            </button>
          </div>

          <div class="tasks-section">
            <app-task-list></app-task-list>
          </div>
        </div>
      </main>

      <footer class="app-footer">
        <p>&copy; 2025 Task Manager - Built with NestJS & Angular 19</p>
      </footer>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .app-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      flex-direction: column;
    }

    .app-header {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
      padding: 2rem 0;
    }

    .header-content {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
      text-align: center;
    }

    .app-title {
      font-size: 2.5rem;
      font-weight: 700;
      color: white;
      margin-bottom: 0.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.75rem;
    }

    .title-icon {
      font-size: 2rem;
    }

    .app-subtitle {
      font-size: 1.125rem;
      color: rgba(255, 255, 255, 0.8);
      font-weight: 300;
    }

    .app-main {
      flex: 1;
      padding: 2rem 0;
    }

    .content-wrapper {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
    }

    .form-section {
      margin-bottom: 2rem;
    }

    .action-bar {
      display: flex;
      justify-content: center;
      margin-bottom: 2rem;
    }

    .btn {
      padding: 0.875rem 1.75rem;
      border-radius: 10px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .btn-primary {
      background: #2563eb;
      color: white;
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);
    }

    .btn-primary:hover {
      background: #1d4ed8;
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(37, 99, 235, 0.5);
    }

    .btn-icon {
      font-size: 1.25rem;
      font-weight: bold;
    }

    .tasks-section {
      animation: fadeIn 0.5s ease-in-out;
    }

    .app-footer {
      background: rgba(0, 0, 0, 0.2);
      color: rgba(255, 255, 255, 0.7);
      text-align: center;
      padding: 1.5rem;
      font-size: 0.875rem;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 768px) {
      .app-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
      }

      .app-subtitle {
        font-size: 1rem;
      }

      .content-wrapper {
        padding: 0 0.75rem;
      }

      .btn {
        padding: 1rem 1.5rem;
        font-size: 0.9rem;
      }
    }
  `]
})
export class App {
  showForm = false;

  showAddForm(): void {
    this.showForm = true;
  }

  onTaskCreated(): void {
    this.showForm = false;
  }

  onFormCancelled(): void {
    this.showForm = false;
  }
}

bootstrapApplication(App, {
  providers: [
    provideHttpClient()
  ]
});